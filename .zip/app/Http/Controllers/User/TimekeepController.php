<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Calendar;
use App\Models\calendar_users;
use App\Models\detail_timekeep;
use App\Models\Qrcode;
use App\Models\Schedule;
use App\Models\timekeep;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Ramsey\Uuid\Type\Time;

class TimekeepController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $timekeeps = $user->calendar_users->flatMap->timekeeps->sortByDesc('date');


        $title = "Thông tin chấm công nhân viên";
        return view('user.timekeep.index', compact('title', 'timekeeps'));
    }

    public function scanner()
    {
        $title = "Chấm công mã qrcode";

        return view('user.timekeep.qrcode', compact('title'));
    }

    public function confirm(Request $request)
    {
        $user = Auth::user();
        $datas = $request->all();
        //Danh sách nhóm qrcode
        $groups = $user->qrcodes;
        $calendars = $user->calendars;
        $calendar_first = $calendars->first();
        $calendar_user = $user->calendar_users;
        $calendarUser = $user->calendar_users->first();
        // Tìm địa chỉ của qrcode
        $qr_code = $groups->where('qr_code', $request->input('qrcode'))->first();
        if ($qr_code == null) {
            return redirect()->route('user.timekeep.scanner')->with('error', 'Đã nhập sai mã QR code hoặc không nhập, xin thử lại');
        }

        // Kiểm tra xem có chấm công hôm nay chưa
        $timekeeps_now = timekeep::whereDate('date', Carbon::today()->toDateString());
        // Nếu chưa chấm công thì sẽ tạo chấm công
        if (!$timekeeps_now->exists()) {
            $timekeep = timekeep::create([
                'calendar_user_id' => $calendar_user->first()->id,
                'date' => Carbon::now()->toDateTimeString(),
            ]);
            if ($datas["in_out"]) {
                $timekeep->update(["time_in" => Carbon::now()]);
            } else {
                $timekeep->update(["time_out" => Carbon::now()]);
            }
        } else {
            if ($datas["in_out"]) {
                $timekeeps_now->first()->update(["time_in" => Carbon::now()]);
            } else {
                $timekeeps_now->first()->update(["time_out" => Carbon::now()]);
            }
        }

        // Tìm kiếm thời khóa biểu chấm công hôm nay (đã có calendar_user first)
        $today = Carbon::today()->dayOfWeek;
        $timekeeps_now = timekeep::whereDate('date', Carbon::today()->toDateString())->first();
        // Tìm ca đẫ chọn ngày hôm
        dd(Carbon::parse($timekeeps_now->time_in) < Carbon::parse("07:15:00"));
        $shedule = Schedule::where("calendar_user_id", $calendarUser->id)->where("day", $today)->first();
        if ($shedule !== null) {
            if (Carbon::parse($timekeeps_now->date)->dayOfWeek == $shedule->day) {
                $timekeeps_now->update(["schedule_id" => $shedule->id]);
                // ca 1 chọn
                if ($shedule->shift_1) {
                    // ca 2 chọn
                    if ($shedule->shift_2) {
                        // ca 3 chọn
                        if ($shedule->shift_3) {
                            if (Carbon::parse($timekeeps_now->time_in) < Carbon::parse("07:15:00")) {
                                detail_timekeep::create([
                                    "timekeep_id" => $timekeeps_now->id,
                                    'status' => 2
                                ]);
                            }
                        }
                    }
                }
            }
        }


        return redirect()->route('user.timekeep.index')->with('success', 'Đã gửi đúng mã qr');
    }
}
